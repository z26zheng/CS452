#ifndef __TRACK_DATA_NEW_H__
#define __TRACK_DATA_NEW_H__

/* THIS FILE IS GENERATED CODE -- DO NOT EDIT */

// The track initialization functions expect an array of this size.
struct _track_node_;

void init_trackb( struct _track_node_ *track);

void init_tracka( struct _track_node_ *track);

#endif
