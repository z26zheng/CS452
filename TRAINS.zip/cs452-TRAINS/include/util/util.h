#ifndef __UTIL_H__
#define __UTIL_H__

#include <global.h>

void idle_percent_task( );

#endif
