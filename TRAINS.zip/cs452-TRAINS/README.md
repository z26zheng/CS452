Woo! Trains!

By Tuo Tony Cui, Ziyou Zheng

How to compile:
run nmake script 
$ ./nmake:exec("tag ".expand("<cword>"))

avialable options:
-c: turn on cache
-o: turn on O2 level optimization
-0: turn on assertion

